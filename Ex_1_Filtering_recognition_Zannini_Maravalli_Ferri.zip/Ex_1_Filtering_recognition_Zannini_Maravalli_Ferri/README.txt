The pdf file, as can be seen, contains the report.
The assignement folder contains all the codes of the
two parts of the exercise. Each of the two folders inside
it, contain all the modules with the functions, the .py
to check that our results are consistent with the requests,
and all the .ipynb notebooks and partial results where we
elaborated the output for the report. 